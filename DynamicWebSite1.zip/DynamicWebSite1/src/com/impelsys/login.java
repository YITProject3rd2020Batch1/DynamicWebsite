package com.impelsys;

import java.io.IOException;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out= response.getWriter(); 
		String msg=null;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
			Connection  con=DriverManager.getConnection( "jdbc:mysql://localhost:3307/test123","root",""); 
			PreparedStatement  stmt =con.prepareStatement("select * from regis where e=? and p=?");    
			String n=request.getParameter("username");  
			 String p=request.getParameter("userpass");
			int nor1=0,nor2=0,nor=0;
			stmt.setString(1, n);
			stmt.setString(2, p);
			ResultSet rs3=stmt.executeQuery();
		    while (rs3.next())
		    {
		    	nor=1;
		    }
				PreparedStatement  stmt1 =con.prepareStatement("select * from regis where e=? ");    
			    stmt1.setString(1, n);
			    ResultSet rs=stmt1.executeQuery();
			    while (rs.next())
			    {
			    	nor1=1;
			    }
			    PreparedStatement  stmt2 =con.prepareStatement("select * from regis where p=? ");    
			    stmt2.setString(1, p);
			    ResultSet rs1=stmt2.executeQuery();
			    while (rs1.next())
			    {
			    	nor2=1;
			    }
			  
			 con.close();
			 if(nor>0)
			 {
				 msg="Welcome!!!!";
				 out.println("<font color=red size=5>"+msg+"</font>");
			 }else
			  if(nor1>0)
			    {
			    	out.println("Invalid password");
			    	RequestDispatcher rd=request.getRequestDispatcher("/login.html");
							rd.include(request, response);
			    }
			    else if(nor2>0)
			    {
			    	out.println("invalid email");
			    	RequestDispatcher rd=request.getRequestDispatcher("/login.html");
							rd.include(request, response);
			    }
			    else 
			    {
			    	out.println("Invalid email and password");
			    	RequestDispatcher rd=request.getRequestDispatcher("/login.html");
							rd.include(request, response);
			    }
			 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			out.println("Error: Not able to perform");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			out.println("Error: Not able to perform");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
