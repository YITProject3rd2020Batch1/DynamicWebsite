package com.impelsys;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter(); 
		String msg=null;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
			Connection  con=DriverManager.getConnection( "jdbc:mysql://localhost:3307/test123","root",""); 
			PreparedStatement  stmt =con.prepareStatement("insert into regis values(?,?,?,?,?,?)");    
  			String e=request.getParameter("userEmail");
			String n=request.getParameter("userName");
			String p=request.getParameter("userPass"); 
			String p1=request.getParameter("userPass1");
			String g=request.getParameter("gender"); 
			String c=request.getParameter("userCollege"); 
			String m[]=request.getParameterValues("qual"); 
          
			String y=m[0];
			int nor=0;
			stmt.setString(1, e);
			stmt.setString(2, n);
			stmt.setString(3, p);
			stmt.setString(4, g);
			stmt.setString(5, c);
			for(int i=1;i<m.length;i++)
			{
				 y=y+","+m[i];
			}
			stmt.setString(6, y);
			if(p.equalsIgnoreCase(p1)){
			  nor= stmt.executeUpdate();
			}
			else
			{
				out.println("<font color=red size=4>password mismatch!!,please enter correct password</font>\n\n");
				RequestDispatcher rd=request.getRequestDispatcher("/register.html");
				rd.include(request, response);
				
			}
			 con.close();
			  if(nor>0)
				 msg="Succesfully registered, please login...";
			 else
				 msg="Couldn't register , please try again!!!";
			 
			 out.println("<font color=green size=5>"+msg+"</font>");
			 RequestDispatcher rd=request.getRequestDispatcher("/login.html");
				rd.include(request, response);
			 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			out.println("Error: Not able to perform");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			out.println("Error: Not able to perform");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
